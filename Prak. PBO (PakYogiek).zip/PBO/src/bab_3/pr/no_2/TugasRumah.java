package bab_3.pr.no_2;

public class TugasRumah {
    double nilaiMID;
    double nilaiTugas;
    double nilaiUAS;
    double nilaiTotal;

    public double getNilaiMID() {
        return nilaiMID;
    }

    public void setNilaiMID(double nilaiMID) {
        this.nilaiMID = nilaiMID;
    }

    public double getNilaiTugas() {
        return nilaiTugas;
    }

    public void setNilaiTugas(double nilaiTugas) {
        this.nilaiTugas = nilaiTugas;
    }

    public double getNilaiUAS() {
        return nilaiUAS;
    }

    public void setNilaiUAS(double nilaiUAS) {
        this.nilaiUAS = nilaiUAS;
    }

    public void nilaiTotal() {
        this.nilaiTotal = (nilaiMID + nilaiTugas + nilaiUAS) / 3;
    }
}
