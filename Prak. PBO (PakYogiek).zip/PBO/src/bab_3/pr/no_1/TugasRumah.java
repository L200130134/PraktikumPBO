package bab_3.pr.no_1;

public class TugasRumah {
    int nilaiMID;
    int nilaiTugas;
    int nilaiUAS;

    public int getNilaiMID() {
        return nilaiMID;
    }

    public void setNilaiMID(int nilaiMID) {
        this.nilaiMID = nilaiMID;
    }

    public int getNilaiTugas() {
        return nilaiTugas;
    }

    public void setNilaiTugas(int nilaiTugas) {
        this.nilaiTugas = nilaiTugas;
    }

    public int getNilaiUAS() {
        return nilaiUAS;
    }

    public void setNilaiUAS(int nilaiUAS) {
        this.nilaiUAS = nilaiUAS;
    }
}
