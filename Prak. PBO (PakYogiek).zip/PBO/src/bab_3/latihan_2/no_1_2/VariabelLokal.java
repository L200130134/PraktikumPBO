package bab_3.latihan_2.no_1_2;

public class VariabelLokal {

    private int umur = 10;

    public void usia() {
        int tahunSekarang = 2015;
        int tahunLahir = 1995;
        umur = tahunSekarang - tahunLahir;
        System.out.println("Usia saya : " + umur);
    }

    public void beratBadan() {
        int beratLahir = 2;
        int beratBadan = beratLahir + (umur/2);
        System.out.println("Berat saya : " + beratBadan);
    }
}
