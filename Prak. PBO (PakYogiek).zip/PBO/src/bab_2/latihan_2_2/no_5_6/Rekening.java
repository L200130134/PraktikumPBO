package bab_2.latihan_2_2.no_5_6;

public class Rekening {
    private double saldo;
    private int noRekening;
    private String nama;

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public void setNoRekening(int noRekening) {
        this.noRekening = noRekening;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int checkNoRekening() {
        return noRekening;
    }

    public String checkNama() {
        return nama;
    }

    public double checkSaldo() {
        return saldo;
    }

    public void menabung(int jumlah) {
        this.saldo += jumlah;
    }

    public void menarik(int jumlah) {
        if (this.saldo >= jumlah) this.saldo -= jumlah;
    }

    /* Didalam class rekening tidak bisa eksekusi method transfer
     * dikarenakan ada user yang berbeda, jadi method transfer di berada class utama "RekeningDemo.java"
     * */

    /*
    *  Nomor 6. String nama ==> method "setNama()" dan "checkNama()"
    * */
}
