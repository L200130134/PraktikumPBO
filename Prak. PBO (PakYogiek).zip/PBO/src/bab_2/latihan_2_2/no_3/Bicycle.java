package bab_2.latihan_2_2.no_3;

public class Bicycle {
    private int cadance;
    private int speedup;
    private int gear;

    public void changeCadance(int cadance) {
        this.cadance = cadance;
    }

    public void speedUp(int speedup) {
        this.speedup = speedup;
    }

    public void changeGear(int gear) {
        this.gear = gear;
    }

    public void printInfo () {
        System.out.println(
                "Change candance : " + cadance + "\n" +
                "Speed up : " + speedup + "\n" +
                "Change gear : " + gear
        );
    }

}
