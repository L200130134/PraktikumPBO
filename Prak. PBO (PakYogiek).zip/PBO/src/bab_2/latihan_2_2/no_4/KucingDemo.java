package bab_2.latihan_2_2.no_4;

public class KucingDemo {
    public static void main(String[] args) {
        Kucing kucing = new Kucing();

        kucing.setWarna("Biru");
        kucing.setUmur(15); // day format
        kucing.meong();
    }
}
