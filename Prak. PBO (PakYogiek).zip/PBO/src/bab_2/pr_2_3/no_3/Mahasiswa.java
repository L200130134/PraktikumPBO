package bab_2.pr_2_3.no_3;

public class Mahasiswa {
    private String nama;
    private String nim;
    private String alamat;
    private int semester;

    public String tampilkanNama() {
        return nama;
    }

    public String tampilkanNim() {
        return nim;
    }

    public String tampilkanAlamat() {
        return alamat;
    }

    public int tampilkanSemester() {
        return semester;
    }
}
