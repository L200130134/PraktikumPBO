package bab_2.pr_2_3.no_3;

import java.util.Date;

public class Dosen {
    private String nama;
    private int nik;
    private String pendidikan;
    private Date tglLahir;

    public String tampilkanNama() {
        return nama;
    }

    public int tampilkanNik() {
        return nik;
    }

    public Date tampilkanTglLahir() {
        return tglLahir;
    }
}
