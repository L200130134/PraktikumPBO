package bab_2.pr_2_3.no_1;

import javax.swing.*;

public class Kalimat {
    public static void main(String[] args) {
        String textInput = JOptionPane.showInputDialog(null, "Tuliskan sebuah kalimat");

        if (textInput != null) {
            JOptionPane.showMessageDialog(null, "Jumlah karakter : " + textInput.length());
        }
    }
}
