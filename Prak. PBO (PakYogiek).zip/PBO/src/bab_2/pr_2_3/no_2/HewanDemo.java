package bab_2.pr_2_3.no_2;

public class HewanDemo {
    public static void main(String[] args) {
        Hewan hewan1 = new Hewan();
        Hewan hewan2 = new Hewan();

        hewan1.setNama("Harimau");
        hewan1.setKaki(4);
        hewan1.setMakanan("Daging");
        hewan1.setType("Karnivora");

        hewan2.setNama("Kerbau");
        hewan2.setKaki(4);
        hewan2.setMakanan("Rumput");
        hewan2.setType("Herbivora");

        hewan1.infoHewan();
        hewan2.infoHewan();
    }
}
