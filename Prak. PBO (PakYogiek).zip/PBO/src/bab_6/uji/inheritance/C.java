package bab_6.uji.inheritance;

public class C extends B {
    public void messageC() {
        System.out.println("Info dari Kelas C");
    }
}
