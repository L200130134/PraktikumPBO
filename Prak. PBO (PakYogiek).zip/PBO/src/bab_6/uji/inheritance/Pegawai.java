package bab_6.uji.inheritance;

public class Pegawai {
    protected double gajiPokok = 100000;
}
