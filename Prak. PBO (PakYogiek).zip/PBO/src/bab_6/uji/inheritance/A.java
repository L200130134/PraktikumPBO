package bab_6.uji.inheritance;

public class A {
    public void messageA() {
        System.out.println("Info dari Kelas A");
    }
}
