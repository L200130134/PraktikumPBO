package bab_6.uji.override;

import bab_6.uji.inheritance.Pegawai;

public class TestHewan extends Pegawai{
    public static void main (String[] args) {

        Hewan hewan = new Hewan();
        Kucing kucing = new Kucing();
        Elang elang = new Elang();

        hewan.gerak();
        kucing.gerak();
        elang.gerak();
    }
}
