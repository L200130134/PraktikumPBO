package bab_6.uji.override;

class Elang extends Hewan {
    public void gerak() {
        System.out.println("Hewan bisa berjalan, berlari dan terbang");
    }
}
