package bab_4.latihan_4_3_1;

public class ProtectedModifier {

    protected void printInfo() {
        System.out.println("Protected Modifier");
    }
    protected void sendMessage() {
        System.out.println("this is a message");
    }
}
