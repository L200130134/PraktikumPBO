package bab_4.latihan_4_4_1;

public class PrivateModifier {

    private String nama;
    private int umur;
    private void printInfo() {
        System.out.println("Private Modifier");
    }
}
