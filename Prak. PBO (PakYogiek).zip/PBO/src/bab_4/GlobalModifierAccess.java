package bab_4;

//import bab_4.latihan_4_1_1.DefaultModifier;

import bab_4.latihan_4_2_1.PublicModifier;
import bab_4.latihan_4_3_1.ProtectedModifier;
import bab_4.latihan_4_4_1.PrivateModifier;

public class GlobalModifierAccess {
    public static void main(String[] args) {
        //DefaultModifier defaultModifier = new DefaultModifier();
        //defaultModifier.jumlah();

        PublicModifier publicModifier = new PublicModifier();
        //publicModifier.kali();

        ProtectedModifier protectedModifier = new ProtectedModifier();
        //protectedModifier.printInfo();

        PrivateModifier privateModifier = new PrivateModifier();
        //privateModifier.printInfo();
    }
}
