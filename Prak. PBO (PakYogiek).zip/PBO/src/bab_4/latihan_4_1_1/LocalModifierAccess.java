package bab_4.latihan_4_1_1;

import bab_4.latihan_4_1_1.DefaultModifier;

public class LocalModifierAccess {
    public static void main(String[] args) {
        DefaultModifier defaultModifier = new DefaultModifier();
        defaultModifier.jumlah();
    }
}
