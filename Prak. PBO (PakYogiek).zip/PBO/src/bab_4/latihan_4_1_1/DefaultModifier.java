package bab_4.latihan_4_1_1;

class DefaultModifier {
    int a = 1;
    int b = 2;
    int c;

    void jumlah() {
        c = a+b;
        System.out.println(c);
    }
}
