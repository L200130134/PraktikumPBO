package bab_5.latihan_5_2_1;

public class AksesBuku {
    public static void main(String[] args) {
        Buku buku1 = new Buku("Pengarang 1", "Judul buku 1", "2001", 1, 50000);
        Buku buku2 = new Buku("Pengarang 2", "Judul buku 2", "2002", 3, 21000);
        Buku buku3 = new Buku("Pengarang 3", "Judul buku 3", "2003", 4, 32000);
        Buku buku4 = new Buku("Pengarang 4", "Judul buku 4", "2004",  6, 56000);
        Buku buku5 = new Buku("Pengarang 5", "Judul buku 5", "2005", 3, 34000);
        Buku buku6 = new Buku("Pengarang 6", "Judul buku 6", "2007", 1, 40000);
        Buku buku7 = new Buku("Pengarang 7", "Judul buku 7", "2008", 6, 30000);
        Buku buku8 = new Buku("Pengarang 8", "Judul buku 8", "2009", 3, 40000);
        Buku buku9 = new Buku("Pengarang 9", "Judul buku 9", "2010", 2, 63000);
        Buku buku10 = new Buku("Pengarang 10", "Judul buku 10", "2011", 5, 54000);

        System.out.println(
                "Nama Pengarang : " + buku1.getNamaPengarang() +", "+ "Judul buku : " + buku1.getJudulBuku() +", "+ "Tahun terbit : " + buku1.getTahunTerbit() +", "+ "Catatan ke- : " + buku1.getCatatanKe() +", "+ "Harga jual : " + buku1.getHargaJual() + "\n" +
                "Nama Pengarang : " + buku2.getNamaPengarang() +", "+ "Judul buku : " + buku2.getJudulBuku() +", "+ "Tahun terbit : " + buku2.getTahunTerbit() +", "+ "Catatan ke- : " + buku2.getCatatanKe() +", "+ "Harga jual : " + buku2.getHargaJual() + "\n" +
                "Nama Pengarang : " + buku3.getNamaPengarang() +", "+ "Judul buku : " + buku3.getJudulBuku() +", "+ "Tahun terbit : " + buku3.getTahunTerbit() +", "+ "Catatan ke- : " + buku3.getCatatanKe() +", "+ "Harga jual : " + buku3.getHargaJual() + "\n" +
                "Nama Pengarang : " + buku4.getNamaPengarang() +", "+ "Judul buku : " + buku4.getJudulBuku() +", "+ "Tahun terbit : " + buku4.getTahunTerbit() +", "+ "Catatan ke- : " + buku4.getCatatanKe() +", "+ "Harga jual : " + buku4.getHargaJual() + "\n" +
                "Nama Pengarang : " + buku5.getNamaPengarang() +", "+ "Judul buku : " + buku5.getJudulBuku() +", "+ "Tahun terbit : " + buku5.getTahunTerbit() +", "+ "Catatan ke- : " + buku5.getCatatanKe() +", "+ "Harga jual : " + buku5.getHargaJual() + "\n" +
                "Nama Pengarang : " + buku6.getNamaPengarang() +", "+ "Judul buku : " + buku6.getJudulBuku() +", "+ "Tahun terbit : " + buku6.getTahunTerbit() +", "+ "Catatan ke- : " + buku6.getCatatanKe() +", "+ "Harga jual : " + buku6.getHargaJual() + "\n" +
                "Nama Pengarang : " + buku7.getNamaPengarang() +", "+ "Judul buku : " + buku7.getJudulBuku() +", "+ "Tahun terbit : " + buku7.getTahunTerbit() +", "+ "Catatan ke- : " + buku7.getCatatanKe() +", "+ "Harga jual : " + buku7.getHargaJual() + "\n" +
                "Nama Pengarang : " + buku8.getNamaPengarang() +", "+ "Judul buku : " + buku8.getJudulBuku() +", "+ "Tahun terbit : " + buku8.getTahunTerbit() +", "+ "Catatan ke- : " + buku8.getCatatanKe() +", "+ "Harga jual : " + buku8.getHargaJual() + "\n" +
                "Nama Pengarang : " + buku9.getNamaPengarang() +", "+ "Judul buku : " + buku9.getJudulBuku() +", "+ "Tahun terbit : " + buku9.getTahunTerbit() +", "+ "Catatan ke- : " + buku9.getCatatanKe() +", "+ "Harga jual : " + buku9.getHargaJual() + "\n" +
                "Nama Pengarang : " + buku10.getNamaPengarang() +", "+ "Judul buku : " + buku10.getJudulBuku() +", "+ "Tahun terbit : " + buku10.getTahunTerbit() +", "+ "Catatan ke- : " + buku10.getCatatanKe() +", "+ "Harga jual : " + buku10.getHargaJual() + "\n"
        );

        /*
        * Seharusanya menggunakan arrayList
        * */
    }
}
