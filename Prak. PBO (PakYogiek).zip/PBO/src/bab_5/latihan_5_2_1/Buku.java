package bab_5.latihan_5_2_1;

public class Buku {
    private String namaPengarang;
    private String judulBuku;
    private String tahunTerbit;
    private int catatanKe;
    private double hargaJual;


    public Buku(String namaPengarang, String judulBuku, String tahunTerbit, int catatanKe, double hargaJual) {
        this.namaPengarang = namaPengarang;
        this.judulBuku = judulBuku;
        this.tahunTerbit = tahunTerbit;
        this.catatanKe = catatanKe;
        this.hargaJual = hargaJual;
    }

    public String getNamaPengarang() {
        return namaPengarang;
    }

    public String getJudulBuku() {
        return judulBuku;
    }

    public String getTahunTerbit() {
        return tahunTerbit;
    }

    public int getCatatanKe() {
        return catatanKe;
    }

    public double getHargaJual() {
        return hargaJual;
    }
}
