package bab_5.latihan_5_3_1.no_2;

import bab_5.latihan_5_3_1.no_1.OverloadingKonstruktor;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class OverloadingKonstruktorMain {
    public static void main(String[] args) {

        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();

        // Default konstruktor
        OverloadingKonstruktor defaultKonstruktor = new OverloadingKonstruktor();

        // Overloading konstruktor
        OverloadingKonstruktor overloadingKonstruktor1 = new OverloadingKonstruktor(1, "l200130134");
        OverloadingKonstruktor overloadingKonstruktor3 = new OverloadingKonstruktor(1, dateFormat.format(date));
        OverloadingKonstruktor overloadingKonstruktor2 = new OverloadingKonstruktor(1, 5);
    }
}
