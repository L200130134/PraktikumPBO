package bab_5.latihan_5_3_1.no_1;

import java.util.Date;

public class OverloadingKonstruktor {
    int idUser;
    String userName;
    int level;
    Date lastLogin;

    public OverloadingKonstruktor() {
    }

    public OverloadingKonstruktor(int idUser, String userName) {
        this.idUser = idUser;
        this.userName = userName;
    }

    public OverloadingKonstruktor(int idUser, Date lastLogin) {
        this.idUser = idUser;
        this.lastLogin = lastLogin;
    }

    public OverloadingKonstruktor(int idUser, int level) {
        this.idUser = idUser;
        this.level = level;
    }

    public OverloadingKonstruktor(int idUser, String userName, int level, Date lastLogin) {
        this.idUser = idUser;
        this.userName = userName;
        this.level = level;
        this.lastLogin = lastLogin;
    }
}
