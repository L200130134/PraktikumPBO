package bab_5.latihan_5_3_1.no_3;

import java.util.Date;

public class CustomerData {
    String nama;
    String alamat;
    Date tglLahir;
    String pekerjaan;
    double gaji;

    public CustomerData() {
    }

    public CustomerData(String nama, String alamat, Date tglLahir, String pekerjaan, double gaji) {
        this.nama = nama;
        this.alamat = alamat;
        this.tglLahir = tglLahir;
        this.pekerjaan = pekerjaan;
        this.gaji = gaji;
    }
}
