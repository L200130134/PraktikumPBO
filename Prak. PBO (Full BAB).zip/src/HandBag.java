public class HandBag {

    int hargaTas;
    String merkTas;
    int banyakTas;

    public int getHargaTas() {
        return hargaTas;
    }

    public void setHargaTas(int hargaTas) {
        this.hargaTas = hargaTas;
    }

    public String getMerkTas() {
        return merkTas;
    }

    public void setMerkTas(String merkTas) {
        this.merkTas = merkTas;
    }

    public int getBanyakTas() {
        return banyakTas;
    }

    public void setBanyakTas(int banyakTas) {
        this.banyakTas = banyakTas;
    }
}
