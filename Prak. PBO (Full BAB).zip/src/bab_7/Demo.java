package bab_7;

public class Demo {
    public static void main(String[] args) {
        Programmer programmer = new Programmer();
        Karyawan karyawan = new Programmer();

        karyawan.setGaji(8000000);
        karyawan.setNama("Riky Ahmad F");
        karyawan.setJabatan("Manager");
        karyawan.setNik("L200130134");

        System.out.println(
                "Nama : " + karyawan.getNama() + "\n" +
                "NIK : " + karyawan.getNik() + "\n" +
                "Gaji : " + karyawan.getGaji() + "\n" +
                "Jabatan : " + karyawan.getJabatan() + "\n\n" +
                "---------------------------------------------------------------\n"
        );

        System.out.println("Jam kerja programmer: " + programmer.jamKerja);
    }
}
