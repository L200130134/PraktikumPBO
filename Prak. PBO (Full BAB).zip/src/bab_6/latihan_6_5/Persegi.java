package bab_6.latihan_6_5;

class Persegi extends BangunDatar {
    protected double sisi;
}
