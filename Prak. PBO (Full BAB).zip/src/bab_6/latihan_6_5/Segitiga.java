package bab_6.latihan_6_5;

class Segitiga extends BangunDatar {
    protected double alas;
}
