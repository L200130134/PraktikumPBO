package bab_6.latihan_6_5;

class SegitigaSamaSisi extends Segitiga {
    protected double sisi;
}
