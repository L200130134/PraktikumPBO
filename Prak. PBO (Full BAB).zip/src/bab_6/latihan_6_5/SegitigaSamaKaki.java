package bab_6.latihan_6_5;

class SegitigaSamaKaki extends Segitiga {
    protected double sisiMiring;
}
