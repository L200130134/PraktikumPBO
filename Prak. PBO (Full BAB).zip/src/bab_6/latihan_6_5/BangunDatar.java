package bab_6.latihan_6_5;

class BangunDatar {
    protected double luas;
    protected double keliling;

    protected void hitungLuas() {
        System.out.println("Luas bangun datar");
    }
    protected double hitungKeliling() {
        return keliling;
    }
}
