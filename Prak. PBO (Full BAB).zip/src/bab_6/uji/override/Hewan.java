package bab_6.uji.override;

class Hewan {
    public void gerak() {
        System.out.println("Hewan bisa berjalan");
    }
}
