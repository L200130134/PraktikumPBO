package bab_6.uji.override;

public class TestHewan {
    public static void main (String[] args) {

        Hewan hewan = new Hewan();
        Kucing kucing = new Kucing();
        Elang elang = new Elang();

        Hewan overide = new Elang();

        hewan.gerak();
        kucing.gerak();
        elang.gerak();

        overide.gerak();
    }
}
