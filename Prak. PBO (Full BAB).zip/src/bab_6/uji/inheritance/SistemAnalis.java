package bab_6.uji.inheritance;

public class SistemAnalis extends Pegawai{
    public static void main (String[] args) {
        double lemburPerJam = 70000;
        double gajiPerbulan;
        Pegawai p = new Pegawai();
        gajiPerbulan = p.gajiPokok+lemburPerJam;
        System.out.println(gajiPerbulan);
    }
}
