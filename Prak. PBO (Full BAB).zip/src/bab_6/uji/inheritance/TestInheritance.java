package bab_6.uji.inheritance;

public class TestInheritance {
    public static void main (String[] args) {
        A a = new A();
        B b = new B();
        C c = new C();

        a.messageA();
        b.messageA();
        b.messageB();
        c.messageA();
        c.messageB();
        c.messageB();
    }
}
