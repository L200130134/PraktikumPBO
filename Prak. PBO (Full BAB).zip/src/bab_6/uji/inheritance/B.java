package bab_6.uji.inheritance;

public class B extends A {
    public void messageB() {
        System.out.println("Info dari Kelas B");
    }
}
