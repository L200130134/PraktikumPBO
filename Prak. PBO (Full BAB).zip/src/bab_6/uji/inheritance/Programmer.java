package bab_6.uji.inheritance;

public class Programmer extends Pegawai{
    public static void main (String[] args) {
        double lemburPerJam = 50000;
        double gajiPerbulan;
        Pegawai p = new Pegawai();
        gajiPerbulan = p.gajiPokok+lemburPerJam;
        System.out.println(gajiPerbulan);

        /*
        * Variable gajiPokok dari class Pegawai dibuat protected untuk membedakan dalam penggunaan inheritance variable
        * */
    }
}
