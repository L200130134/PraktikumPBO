public class Pembelian {

    static Customer customer;
    static HandBag handBag;

    public static void main(String[] s){
        Customer member = new Customer();
        HandBag pesanTAs = new HandBag();

        member.setNama("Riky Ahmad");
        member.setAlamat("Sragen");
        member.setID(134);
        member.setOngkir(25000);

        //pembelian();
    }

    public static void pembelian(Customer mcustomer, HandBag mhandBag) {

        customer = mcustomer;
        handBag = mhandBag;

    }

    public static void tampilkanDataPembeli() {
            System.out.println("Nama : " + customer.getNama());
            System.out.println("Alamat : " + customer.getAlamat());
            System.out.println("Ongkir : " + customer.getOngkir());
            System.out.println("Merk Tas : " + handBag.getMerkTas());
            System.out.println("Harga Tas : " + handBag.getMerkTas());
            System.out.println("Jumlah Tas : " + handBag.getMerkTas());
    }
}
