package bab_10;

import java.util.Scanner;

public class AplikasiLampu {
    public static void main(String[] s) {
        Lampu lampu = new Lampu();
        Scanner scanner = new Scanner(System.in);
        lampu.statusLampu = lampu.setSaklar(0);
        System.out.println("Status Lampu = " + lampu.statusLampu + "\nketikan");
        System.out.println("1. untuk menyalakan lampu\n0. untuk mematikan lampu");

        if(lampu.setSaklar(scanner.nextInt()) == 0) {
            lampu.matikanLampu();
        } else {
            lampu.hidupkanLampu();
        }
    }
}
