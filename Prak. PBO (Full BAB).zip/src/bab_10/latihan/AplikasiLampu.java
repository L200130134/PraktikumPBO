package bab_10.latihan;

import bab_10.Lampu;

import java.util.Scanner;

public class AplikasiLampu {
    public static void main(String[] s) {
        Lampu lampu = new Lampu();
        Scanner scanner = new Scanner(System.in);
        lampu.statusLampu = lampu.setSaklar(0);
        System.out.println("Status Lampu = " + lampu.statusLampu + "\nketikan");
        System.out.println("0. untuk mematikan lampu\n1. untuk menyalakan lampu\n2. untuk meredupkan lampu\n\n");

        int option = scanner.nextInt();

        if(lampu.setSaklar(option) == 0) {
            lampu.matikanLampu();
        } else if(lampu.setSaklar(option) == 1){
            lampu.hidupkanLampu();
        } else if(lampu.setSaklar(option) == 2){
            lampu.redupkanLampu();
        }
    }
}
