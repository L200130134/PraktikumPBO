package bab_10;

interface Animal {
    public void eat();
    public void travel();
}
