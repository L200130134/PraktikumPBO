package bab_3.latihan_3;

public class Pegawai {
    String nama;
    int nip;
    double gaji;

    public Pegawai(String nama, int nip, double gaji) {
        this.nama = nama;
        this.nip = nip;
        this.gaji = gaji;
    }

    public String getNama() {
        return nama;
    }

    public int getNip() {
        return nip;
    }

    public double getGaji() {
        return gaji;
    }
}
