package bab_3.latihan_3;

public class PegawaiDemo {

    public static void main(String[] args) {
        Pegawai pegawai1 = new Pegawai("Pegawai 1", 123, 3000000);
        Pegawai pegawai2 = new Pegawai("Pegawai 2", 122, 6000000);
        Pegawai pegawai3 = new Pegawai("Pegawai 3", 124, 5000000);
        Pegawai pegawai4 = new Pegawai("Pegawai 4", 234, 3000000);
        Pegawai pegawai5 = new Pegawai("Pegawai 5", 235, 4000000);

        System.out.println(
                "Nama Pegawai 1 : " + pegawai1.getNama() +", "+ "NIP Pegawai 1 : " + pegawai1.getNip() +", "+ "Gaji Pegawai 1 : " + pegawai1.getGaji() + "\n" +
                "Nama Pegawai 2 : " + pegawai2.getNama() +", "+ "NIP Pegawai 2 : " + pegawai2.getNip() +", "+ "Gaji Pegawai 2 : " + pegawai2.getGaji() + "\n" +
                "Nama Pegawai 3 : " + pegawai3.getNama() +", "+ "NIP Pegawai 3 : " + pegawai3.getNip() +", "+ "Gaji Pegawai 3 : " + pegawai3.getGaji() + "\n" +
                "Nama Pegawai 4 : " + pegawai4.getNama() +", "+ "NIP Pegawai 4 : " + pegawai4.getNip() +", "+ "Gaji Pegawai 4 : " + pegawai4.getGaji() + "\n" +
                "Nama Pegawai 5 : " + pegawai5.getNama() +", "+ "NIP Pegawai 5 : " + pegawai5.getNip() +", "+ "Gaji Pegawai 5 : " + pegawai5.getGaji() + "\n"
        );
    }

    
}
