package bab_3;

public class MethodReturnMain {
    public static void main(String[] args) {
        MethodReturn methodReturn = new MethodReturn();

        methodReturn.nama = "Riky Ahmad Fathoni";
        methodReturn.id = "L200130134";

        System.out.println(
                "Nama : " + methodReturn.getNama() + "\n" +
                "NIM : " + methodReturn.getNIM() + "\n"
        );
    }
}
