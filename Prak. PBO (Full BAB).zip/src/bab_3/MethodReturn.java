package bab_3;

public class MethodReturn {
    String nama;
    String id;

    public String getNama() {
        return nama;
    }
    
    public String getNIM() {
        return id;
    }
}
