package bab_11;

class NestedClass {
    String nama = "Riky Ahmad Fathoni";
    String nim = "L200130134";

    public void printNama() {
        System.out.println(nama + " : " + nim);
    }

    static class StaticNestedClass {
        static String jurusan = "informatika";

        void printNama() {
            NestedClass nestedClass = new NestedClass();
            nestedClass.printNama();
        }
    }

    class InnerClass {

        void printJurusan() {
            System.out.println(StaticNestedClass.jurusan);
        }
    }

    public static void main(String[] s) {

        NestedClass.StaticNestedClass nestedClass = new NestedClass.StaticNestedClass();
        nestedClass.printNama();

        NestedClass.InnerClass innerClass = new NestedClass().new InnerClass();
        innerClass.printJurusan();
    }
}
