public class Customer {

    int ID;
    String Nama;
    String Alamat;
    int Ongkir;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNama() {
        return Nama;
    }

    public void setNama(String nama) {
        Nama = nama;
    }

    public String getAlamat() {
        return Alamat;
    }

    public void setAlamat(String alamat) {
        Alamat = alamat;
    }

    public int getOngkir() {
        return Ongkir;
    }

    public void setOngkir(int ongkir) {
        Ongkir = ongkir;
    }
}
