package bab_2.pr_2_3.no_2;

public class Hewan {
    private String nama;
    private int kaki;
    private String makanan;
    private String type;

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setKaki(int kaki) {
        this.kaki = kaki;
    }

    public void setMakanan(String makanan) {
        this.makanan = makanan;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void infoHewan() {
        System.out.println(
                "Nama Dosen : " + nama + "\n" +
                "Jumlah Kaki : " + kaki + "\n" +
                "Makanan : " + makanan + "\n" +
                "Type Dosen : " + type + "\n"
        );
    }
}
