package bab_2.pr_2_3.no_3;

public class Karyawan {
    private String nama;
    private String alamat;
    private String jabatan;
    private double gaji;

    public String tampilkanNama() {
        return nama;
    }

    public String tampilkanAlamat() {
        return alamat;
    }

    public String tampilkanJabatan() {
        return jabatan;
    }

    public double tampilkanGaji() {
        return gaji;
    }
}
