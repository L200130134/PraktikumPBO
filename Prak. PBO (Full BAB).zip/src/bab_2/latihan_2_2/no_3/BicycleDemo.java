package bab_2.latihan_2_2.no_3;

public class BicycleDemo {
    public static void main(String[] args) {
        Bicycle bicycle = new Bicycle();

        bicycle.changeCadance(50);
        bicycle.speedUp(20);
        bicycle.changeGear(2);
        bicycle.printInfo();

        bicycle.changeCadance(50);
        bicycle.speedUp(20);
        bicycle.changeGear(2);
        bicycle.changeCadance(40);
        bicycle.speedUp(10);
        bicycle.changeGear(1);
        bicycle.printInfo();
    }
}
