package bab_2.latihan_2_2.no_1;

public class Rotiku {
    private String warna;
    private String rasa;
    private int berat;
    private double harga;

    public void beriWarna(String warna) {
        this.warna = warna;
    }

    public void beriRasa(String rasa) {
        this.rasa = rasa;
    }

    public void timbangBerat(int berat) {
        this.berat = berat;
    }

    public void hargaJual(double harga) {
        this.harga = harga;
    }

    // added modification
    public String getWarna() {
        return warna;
    }

    public String getRasa() {
        return rasa;
    }

    public int getBerat() {
        return berat;
    }

    public double getHarga() {
        return harga;
    }

    public void infoRoti () {
        System.out.println(
                "Warna roti : " + warna + "\n" +
                "Rasa roti : " + rasa + "\n" +
                "Berat roti : " + berat + "\n" +
                "Harga roti : " + harga
        );
    }

}
