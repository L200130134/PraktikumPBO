package bab_2.latihan_2_2.no_1;

public class RotiEnak {
    public static void main(String[] args) {
        Rotiku rotiku = new Rotiku();

        rotiku.beriWarna("Merah");
        rotiku.beriRasa("Keju");
        rotiku.timbangBerat(45);
        rotiku.hargaJual(10000);
        rotiku.infoRoti();

        // added modification access
        System.out.println("Get warna roti : " + rotiku.getWarna());
        System.out.println("Get rasa roti : " + rotiku.getRasa());
        System.out.println("Get berat roti : " + rotiku.getBerat());
        System.out.println("Get harga roti : " + rotiku.getHarga());
    }
}
