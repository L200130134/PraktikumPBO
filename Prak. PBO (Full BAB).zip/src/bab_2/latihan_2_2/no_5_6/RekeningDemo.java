package bab_2.latihan_2_2.no_5_6;

import javax.swing.*;

public class RekeningDemo {
    public static void main(String[] args) {

        Rekening rekening1 = new Rekening();
        Rekening rekening2 = new Rekening();

        rekening1.setNama("Riky Ahmad Fathoni");
        rekening1.setNoRekening(123456);
        rekening1.setSaldo(500000);

        rekening2.setNama("Another User");
        rekening2.setNoRekening(654321);
        rekening2.setSaldo(100000);

        String option = JOptionPane.showInputDialog(null, "Select bank option : " + "\n" +
                "1 : Cek saldo" + "\n" +
                "2 : Menabung" + "\n" +
                "3 : Menarik" + "\n" +
                "4 : Transfer" + "\n");

        if (option != null) {
            int selected = Integer.parseInt(option);

            if (selected == 1) {
                showDialog("Total saldo anda Rp. " + rekening1.checkSaldo());
            } else if (selected == 2) {
                String menabung = JOptionPane.showInputDialog(null, "Masukkan jumlah (Rp)");

                if (menabung != null) {
                    int jumlah = Integer.parseInt(menabung);
                    rekening1.menabung(jumlah);

                    showDialog("Transaksi sukses, total saldo anda Rp. " + rekening1.checkSaldo());
                }
            } else if (selected == 3) {
                String menarik = JOptionPane.showInputDialog(null, "Masukkan jumlah (Rp)");

                if (menarik != null) {
                    int jumlah = Integer.parseInt(menarik);

                    if (rekening1.checkSaldo() < jumlah) {
                        showDialog("Saldo tidak mencukupi, total saldo anda Rp. " + rekening1.checkSaldo());
                    } else {
                        rekening1.menarik(jumlah);
                        showDialog("Transaksi sukses, total saldo anda Rp. " + rekening1.checkSaldo());
                    }
                }
            } else if (selected == 4) {
                String transfer = JOptionPane.showInputDialog(null, "Masukkan jumlah transfer (Rp)");

                if (transfer != null) {
                    int jumlah = Integer.parseInt(transfer);

                    if (rekening1.checkSaldo() < jumlah) {
                        showDialog("Saldo tidak mencukupi, total saldo anda Rp. " + rekening1.checkSaldo());
                    } else {
                        rekening1.menarik(jumlah);
                        rekening2.menabung(jumlah);
                        showDialog(
                                "Transaksi sukses, total saldo anda Rp. " + rekening1.checkSaldo() + "\n" +
                                "Dan total saldo " + rekening2.checkNama() + " Rp." + rekening2.checkSaldo()
                        );
                    }
                }

                /*
                * Method transfer seharusnya menggunakan database untuk list data user.
                * */
            } else {
                showDialog("Not valid selection");
            }
        }
    }

    private static void showDialog(String message) {
        JOptionPane.showMessageDialog(null, message);
    }
}
