package bab_2.latihan_2_2.no_4;

public class Kucing {
    private int umur;
    private String warna;

    public void setUmur(int umur) {
        this.umur = umur;
    }

    public void setWarna(String warna) {
        this.warna = warna;
    }

    public void meong () {
        System.out.println(
                "Warna Dosen : " + warna + "\n" +
                "Umur Dosen : " + umur + " hari"
        );
    }
}
