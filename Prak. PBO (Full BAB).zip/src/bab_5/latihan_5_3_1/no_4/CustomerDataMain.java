package bab_5.latihan_5_3_1.no_4;


import bab_5.latihan_5_3_1.no_3.CustomerData;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CustomerDataMain {
    public static void main(String[] args) {

        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();

        // Default konstruktor
        CustomerData customerData1 = new CustomerData("Riky Ahmad Fathoni", "Sragen", date, "Mahasiswa", 0);
        CustomerData customerData2 = new CustomerData("Customer 1", "Surakarta", date, "Karyawan", 5000000);
        CustomerData customerData3 = new CustomerData("Customer 2", "Klaten", date, "Karyawan", 2000000);
        CustomerData customerData4 = new CustomerData("Customer 3", "Boyolali", date, "Karyawan", 4000000);
        CustomerData customerData5 = new CustomerData("Customer 4", "Kartosuro", date, "PNS", 3000000);
        CustomerData customerData6 = new CustomerData("Customer 5", "Purwodadi", date, "Karyawan", 4000000);
        CustomerData customerData7 = new CustomerData("Customer 6", "Sragen", date, "Karyawan", 3000000);
        CustomerData customerData8 = new CustomerData("Customer 7", "Karanganyar", date, "Karyawan", 4000000);
        CustomerData customerData9 = new CustomerData("Customer 8", "Bandung", date, "Karyawan", 3500000);
        CustomerData customerData10 = new CustomerData("Customer 9", "Jakarta", date, "Karyawan", 5600000);
    }
}
