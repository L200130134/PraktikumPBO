package bab_5.latihan_5_1_1;

public class AksesKonstruktor {
    public static void main(String[] args) {
        Konstruktor konstruktor = new Konstruktor();

        konstruktor.setNama("Riky Ahmad Fathoni");
        konstruktor.setNim("L200130134");
        konstruktor.setAlamat("Sragen");

        System.out.println(
                "Nama : " + konstruktor.getNama() + "\n" +
                "NIM : " + konstruktor.getNim() + "\n" +
                "Alamat : " + konstruktor.getAlamat() + "\n"
        );
    }
}
