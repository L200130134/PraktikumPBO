package bab_5.latihan_5_1_1;

public class Konstruktor {
    private String nama;
    private String nim;
    private String alamat;

    public Konstruktor() {
        super();
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNim() {
        return nim;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }
}
