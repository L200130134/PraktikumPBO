package bab_12.pr;

import bab_12.pr.bangunDatar.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LuasBangunDatar {

    public static void main(String[] s) {
        final JFrame frame = new JFrame("Luas Bangun Datar");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setSize(180, 220);
        final JPanel panel = new JPanel();
        frame.getContentPane().setLayout(new GridLayout());

        JButton segitiga = new JButton("Segitiga");
        JButton persegi = new JButton("Persegi");
        JButton persegiPanjang = new JButton("Persegi Panjang");
        JButton jajarGenjang = new JButton("Jajar Genjang");
        JButton layangLayang = new JButton("Layang-Layang");

        ImageIcon imgIcon = new ImageIcon(new ImageIcon(LuasBangunDatar.class.getResource("/bab_12/pr/icon.png"))
                .getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));

        panel.add(segitiga);
        panel.add(persegi);
        panel.add(persegiPanjang);
        panel.add(jajarGenjang);
        panel.add(layangLayang);
        frame.add(panel);
        frame.setVisible(true);

        segitiga.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Segitiga();
            }
        });

        persegi.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Persegi();
            }
        });

        persegiPanjang.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new PersegiPanjang();
            }
        });

        jajarGenjang.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new JajarGenjang();
            }
        });

        layangLayang.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new LayangLayang();
            }
        });
    }
}
