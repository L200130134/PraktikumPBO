package bab_12.pr;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FormColor {

    public static void main(String[] s) {
        final JFrame frame = new JFrame("Form Change Color");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setSize(300, 150);
        final JPanel panel = new JPanel();
        frame.getContentPane().setLayout(new GridLayout());
        JButton red = new JButton("RED");
        JButton green = new JButton("GREEN");
        JButton yellow = new JButton("YELLOW");

        ImageIcon imgIcon = new ImageIcon(new ImageIcon(FormColor.class.getResource("/bab_12/pr/icon.png"))
                .getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));

        red.setIcon(imgIcon);
        green.setIcon(imgIcon);
        yellow.setIcon(imgIcon);

        panel.add(red);
        panel.add(green);
        panel.add(yellow);
        frame.add(panel);
        frame.setVisible(true);

        red.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.setBackground(Color.RED);
            }
        });

        green.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.setBackground(Color.GREEN);
            }
        });

        yellow.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.setBackground(Color.YELLOW);
            }
        });
    }
}
