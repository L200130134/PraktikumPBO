package bab_12.pr.bangunDatar;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Persegi extends JFrame {

    final JTextField sisiTxt = new JTextField(10);
    final JTextField hasilTxt = new JTextField(10);
    JLabel sisi = new JLabel("Sisi ");
    JLabel hasil = new JLabel("Hasilnya ");
    JButton hitungLuas = new JButton("Hitung Luas");

    public Persegi() {
        setTitle("Luas Persegi");
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        setSize(255, 150);

        setLayout(null);
        add(sisi);
        add(sisiTxt);
        add(hasil);
        add(hasilTxt);
        add(hitungLuas);

        sisi.setBounds(10, 10, 80, 20);
        hasil.setBounds(10, 40, 80, 20);
        sisiTxt.setBounds(80, 10, 150, 20);
        hasilTxt.setBounds(80, 40, 150, 20);
        hitungLuas.setBounds(80, 70, 120, 20);

        hasilTxt.setEditable(false);
        setLocationRelativeTo(null);
        setVisible(true);

        hitungLuas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (sisiTxt.getText().equals("")) {
                    JOptionPane.showMessageDialog(null, "Field tidak boleh kosong");
                } else {
                    try {
                        double mSisi = Integer.parseInt(sisiTxt.getText());

                        hasilTxt.setText(String.valueOf(mSisi * mSisi));

                    } catch (Exception er) {
                        JOptionPane.showMessageDialog(null, "Input harus berupa numerik");
                    }
                }
            }
        });
    }
}