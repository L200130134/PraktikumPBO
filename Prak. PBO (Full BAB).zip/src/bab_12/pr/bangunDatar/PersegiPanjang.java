package bab_12.pr.bangunDatar;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PersegiPanjang extends JFrame {

    final JTextField panjangTxt = new JTextField(10);
    final JTextField lebarTxt = new JTextField(10);
    final JTextField hasilTxt = new JTextField(10);
    JLabel panjang = new JLabel("Panjang ");
    JLabel lebar = new JLabel("Lebar ");
    JLabel hasil = new JLabel("Hasilnya ");
    JButton hitungLuas = new JButton("Hitung Luas");

    public PersegiPanjang() {
        setTitle("Luas Persegi Panjang");
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        setSize(255, 200);

        setLayout(null);
        add(panjang);
        add(lebar);
        add(hasil);
        add(hasilTxt);
        add(panjangTxt);
        add(lebarTxt);
        add(hitungLuas);

        panjang.setBounds(10, 10, 80, 20);
        lebar.setBounds(10, 40, 80, 20);
        hasil.setBounds(10, 70, 80, 20);
        panjangTxt.setBounds(80, 10, 150, 20);
        lebarTxt.setBounds(80, 40, 150, 20);
        hasilTxt.setBounds(80, 70, 150, 20);
        hitungLuas.setBounds(80, 100, 120, 20);

        hasilTxt.setEditable(false);
        setLocationRelativeTo(null);
        setVisible(true);

        hitungLuas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (panjangTxt.getText().equals("") || lebarTxt.getText().equals("")) {
                    JOptionPane.showMessageDialog(null, "Semua field tidak boleh kosong");
                } else {
                    try {
                        double mPanjang = Integer.parseInt(panjangTxt.getText());
                        double mLebar = Integer.parseInt(lebarTxt.getText());

                        hasilTxt.setText(String.valueOf(mPanjang * mLebar));

                    } catch (Exception er) {
                        JOptionPane.showMessageDialog(null, "Input harus berupa numerik");
                    }
                }
            }
        });
    }
}