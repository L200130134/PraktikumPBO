package bab_9.latihan;

public class MethodMain {

    public static void main(String[] s) {

        // persegi
        Persegi persegi = new Persegi();
        System.out.println("Keliling Persegi = " + persegi.getKeliling());
        System.out.println("Luas Persegi = " + persegi.getLuas() + "\n");

        // persegi panjang
        PersegiPanjang persegiPanjang = new PersegiPanjang();
        System.out.println("Keliling Persegi Panjang = " + persegiPanjang.getKeliling());
        System.out.println("Luas Persegi Panjang = " + persegiPanjang.getLuas() + "\n");

        // jajargenjang
        JajarGenjang jajarGenjang = new JajarGenjang();
        System.out.println("Keliling Jajar Genjang = " + jajarGenjang.getKeliling());
        System.out.println("Luas Jajar Genjang = " + jajarGenjang.getLuas() + "\n");

        // lingkaran
        Lingkaran lingkaran = new Lingkaran();
        System.out.println("Keliling Lingkaran = " + lingkaran.getKeliling());
        System.out.println("Luas Lingkaran = " + lingkaran.getLuas() + "\n");

        // segitiga
        Segitiga segitiga = new Segitiga();
        System.out.println("Keliling Segitiga = " + segitiga.getKeliling());
        System.out.println("Luas Segitiga = " + segitiga.getLuas());
    }
}
