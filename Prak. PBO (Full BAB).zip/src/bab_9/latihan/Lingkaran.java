package bab_9.latihan;

public class Lingkaran extends MethodAbstrak {
    double phi = 3.14;
    int r = 7;

    @Override
    public int luas() {
        return (int) (phi*(r*r)); //π r2
    }

    @Override
    public int keliling() {
        return (int) (2*phi*r); //2 π r
    }
}
