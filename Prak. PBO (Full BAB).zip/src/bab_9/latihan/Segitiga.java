package bab_9.latihan;

public class Segitiga extends MethodAbstrak {
    int sisiA = 6;
    int sisiB = 7;
    int sisiC = 8;
    int tinggi = 5;

    @Override
    public int luas() {
        return (sisiA*tinggi) / 2;
    }

    @Override
    public int keliling() {
        return sisiA + sisiB + sisiC;
    }
}
