package bab_9.latihan;

public class JajarGenjang extends MethodAbstrak {
    int alas = 20;
    int tinggi = 10;
    int sisiMiring = 15;

    @Override
    public int luas() {
        return alas*tinggi;
    }

    @Override
    public int keliling() {
        return 2*(alas + sisiMiring);
    }
}
