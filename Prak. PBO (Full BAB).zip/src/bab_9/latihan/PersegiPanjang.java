package bab_9.latihan;

public class PersegiPanjang extends MethodAbstrak {
    int panjang = 10;
    int lebar = 7;

    @Override
    public int luas() {
        return panjang*lebar;
    }

    @Override
    public int keliling() {
        return 2*(panjang + lebar);
    }
}
