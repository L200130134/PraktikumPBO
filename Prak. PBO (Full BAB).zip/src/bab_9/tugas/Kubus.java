package bab_9.tugas;

public class Kubus extends MethodAbstrak {
    int panjangRusuk = 5;

    @Override
    public int volume() {
        return panjangRusuk * panjangRusuk * panjangRusuk;
    }

    @Override
    public int luasPermukaan() {
        return 6 * (panjangRusuk * panjangRusuk); // 6 x s2
    }
}
