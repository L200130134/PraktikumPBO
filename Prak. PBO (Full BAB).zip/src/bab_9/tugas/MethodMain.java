package bab_9.tugas;

public class MethodMain {

    public static void main(String[] s) {

        // balok
        Balok balok = new Balok();
        System.out.println("Volume Balok = " + balok.getVolume());
        System.out.println("Luas Permukaan Balok = " + balok.getLuasPermukaan() + "\n");

        // kubus
        Kubus kubus = new Kubus();
        System.out.println("Volume Kubus = " + kubus.getVolume());
        System.out.println("Luas Permukaan Kubus = " + kubus.getLuasPermukaan() + "\n");

        // bola
        Bola bola = new Bola();
        System.out.println("Volume Bola = " + bola.getVolume());
        System.out.println("Luas Permukaan Bola = " + bola.getLuasPermukaan() + "\n");

        // kerucut
        Kerucut kerucut = new Kerucut();
        System.out.println("Volume Kerucut = " + kerucut.getVolume());
        System.out.println("Luas Permukaan Kerucut = " + kerucut.getLuasPermukaan() + "\n");

        // prisma segitiga
        PrismaSegiTiga prismaSegiTiga = new PrismaSegiTiga();
        System.out.println("Volume Prisma Segitiga = " + prismaSegiTiga.getVolume());
        System.out.println("Luas Permukaan Prisma Segitiga = " + prismaSegiTiga.getLuasPermukaan());

    }
}
