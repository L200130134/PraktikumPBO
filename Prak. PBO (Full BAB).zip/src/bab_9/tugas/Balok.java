package bab_9.tugas;

public class Balok extends MethodAbstrak {
    int panjang = 30;
    int lebar = 10;
    int tinggi = 5;

    @Override
    public int volume() {
        return panjang * lebar * tinggi;
    }

    @Override
    public int luasPermukaan() {
        return 2 * ((panjang * lebar) + (panjang * tinggi) + (lebar * tinggi)); // 2(pl + pt + lt)
    }
}
