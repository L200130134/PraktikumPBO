package bab_9.tugas;

public class Bola extends MethodAbstrak {
    double phi = 3.14;
    int jariJari = 5;

    @Override
    public int volume() {
        return (int) ((4 *  phi * (jariJari * jariJari * jariJari)) / 3); // 4/3 π r3
    }

    @Override
    public int luasPermukaan() {
        return (int) (4 * phi * (jariJari * jariJari)); // 4 π r2
    }
}
