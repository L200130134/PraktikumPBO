package bab_9.tugas;

public class Kerucut extends MethodAbstrak {
    double phi = 3.14;
    int jariJari = 7;
    int tinggi = 20;

    @Override
    public int volume() {
        return (int) ((phi * (jariJari * jariJari)) / 3); // 1/3 π r2
    }

    @Override
    public int luasPermukaan() {
        return (int) (phi * jariJari * (jariJari + tinggi)); // π r (r + s)
    }
}
