package bab_9.tugas;

public abstract class MethodAbstrak {
    public abstract int volume();
    public abstract int luasPermukaan();

    public int getVolume() {
        return volume();
    }
    public int getLuasPermukaan() {
        return luasPermukaan();
    }
}
