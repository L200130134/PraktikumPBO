package bab_9.tugas;

public class PrismaSegiTiga extends MethodAbstrak {
    int alasSegitiga = 6;
    int tinggiSegitiga = 8;
    int tinggiPrisma = 10;

    @Override
    public int volume() {
        return luasSegitiga() * tinggiPrisma;
    }

    @Override
    public int luasPermukaan() {
        return (2 * luasSegitiga()) + luasSelimut();
    }

    private int luasSegitiga() {
        return (alasSegitiga * tinggiPrisma) / 2;
    }

    private int luasSelimut() {
        return 3 * tinggiPrisma * tinggiSegitiga;
    }
}
