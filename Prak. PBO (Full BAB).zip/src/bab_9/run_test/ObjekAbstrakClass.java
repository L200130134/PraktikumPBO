package bab_9.run_test;

public class ObjekAbstrakClass {

    public static void main(String[] s) {
        TurunanAbstrakClass tac = new TurunanAbstrakClass(2,3,4);
        tac.printX();
        System.out.println(tac.kali());
    }
}
