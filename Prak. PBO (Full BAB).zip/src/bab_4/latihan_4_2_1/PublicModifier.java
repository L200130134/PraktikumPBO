package bab_4.latihan_4_2_1;

public class PublicModifier {
    int a = 2;
    int b = 5;
    int c = 9;

    public void kali() {
        int d = a*b*c;
        System.out.println("Hasil kali = " + d);
    }

    public void tambah() {
        int d = a+b+c;
        System.out.println("Hasil tambah = " + d);
    }

    public void kurang() {
        int d = a-b-c;
        System.out.println("Hasil kurang = " + d);
    }

    public void bagi() {
        int d = a/b/c;
        System.out.println("Hasil bagi = " + d);
    }
}
