package bab_4.latihan_4_4_1;

public class LocalModifierAccess {
    public static void main(String[] args) {
        PrivateModifier privateModifier = new PrivateModifier();
        //privateModifier.printInfo();
    }
}
