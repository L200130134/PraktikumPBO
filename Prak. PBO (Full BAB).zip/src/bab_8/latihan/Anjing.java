package bab_8.latihan;

public class Anjing extends Pet {

    public String panggilNama() {
        return "BULL";
    }

    public String perilaku() {
        return "Menyukai Daging dan Tulang\nGuk...Guk...Guk...";
    }
}
