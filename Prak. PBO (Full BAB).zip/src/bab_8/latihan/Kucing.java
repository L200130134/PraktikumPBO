package bab_8.latihan;

public class Kucing extends Pet {

    public String panggilNama() {
        return "TOM";
    }

    public String perilaku() {
        return "Menyukai Ikan\nMeoow...Meoow..";
    }
}
