package bab_8.latihan;

public class Pet {
    private String nama;

    public String panggilNama() {
        return nama;
    }

    public void beriNama(String nama) {
        this.nama = nama;
    }

    public String perilaku() {
        return "Hewan Penurut";
    }
}
