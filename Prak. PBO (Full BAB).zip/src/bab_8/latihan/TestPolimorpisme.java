package bab_8.latihan;


public class TestPolimorpisme {
    public static void main(String[] args) {
        Pet pet1 = new Kucing();
        Pet pet2 = new Anjing();

        // pet 1
        System.out.println(pet1.panggilNama() + "\n" + pet1.perilaku());

        //pet 2
        System.out.println(pet2.panggilNama() + "\n" + pet2.perilaku());
    }
}
