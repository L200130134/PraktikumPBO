package bab_8.tugas;

public class BankSyariah extends BankUmum {

    protected int rasioBunga() {
        return 0; // percentage
    }
}
