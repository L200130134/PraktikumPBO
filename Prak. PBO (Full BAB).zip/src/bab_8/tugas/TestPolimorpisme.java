package bab_8.tugas;

public class TestPolimorpisme {
    public static void main(String[] args) {
        Bank bankPribadi = new BankPribadi();
        Bank bankUmum = new BankUmum();
        BankUmum bankPasar = new BankPasar();
        BankUmum bankSyariah = new BankSyariah();

        System.out.println(
                "Rasio bunga " + bankPribadi.rasioBunga() + "%\n" +
                "Rasio bunga " + bankUmum.rasioBunga() + "%\n" +
                "Rasio bunga " + bankPasar.rasioBunga() + "%\n" +
                "Rasio bunga " + bankSyariah.rasioBunga() + "%"
        );
    }
}
