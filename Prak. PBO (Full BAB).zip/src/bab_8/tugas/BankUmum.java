package bab_8.tugas;

public class BankUmum extends Bank {

    protected int rasioBunga() {
        return 6; // percentage
    }
}
