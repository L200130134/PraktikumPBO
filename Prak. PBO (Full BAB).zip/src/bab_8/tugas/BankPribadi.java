package bab_8.tugas;

public class BankPribadi extends Bank {

    protected int rasioBunga() { // harus protected | public modifier
        return 7; // percentage
    }
}
