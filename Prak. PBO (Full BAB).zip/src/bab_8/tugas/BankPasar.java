package bab_8.tugas;

public class BankPasar extends BankUmum {

    protected int rasioBunga() {
        return 8; // percentage
    }
}
