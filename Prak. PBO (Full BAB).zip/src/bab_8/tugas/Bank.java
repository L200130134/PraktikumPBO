package bab_8.tugas;

public class Bank {

    protected int rasioBunga() {
        return 5; // percentage
    }
}
